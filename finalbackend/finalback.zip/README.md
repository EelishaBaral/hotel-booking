This is backend for Booikng system

## Booking system

--In this project you can create user. When you create user you can book hotel and you can comment on that hotels

--This project show best populat hotel and you can search filter and many more
